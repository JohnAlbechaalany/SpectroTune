# Generate sample spectral data for SpectroTune package
# This script creates the sample_spectra dataset

set.seed(42)

# Create wavelength vector (400-2499 nm, 5nm intervals)
wavelengths <- seq(400, 2499, by = 5)
n_wl <- length(wavelengths)

# Generate 150 samples
n_samples <- 150

# Create sample IDs
sample_ids <- paste0("Sample_", sprintf("%03d", 1:n_samples))

# Generate synthetic spectra with realistic characteristics
spectra <- matrix(0, nrow = n_samples, ncol = n_wl)

for (i in 1:n_samples) {
  # Base spectrum with water absorption bands
  base_spectrum <- 0.3 + 0.4 * exp(-((wavelengths - 1000) / 300)^2) +
                   0.2 * exp(-((wavelengths - 1500) / 200)^2) +
                   0.1 * exp(-((wavelengths - 2000) / 150)^2)
  
  # Add noise
  noise <- rnorm(n_wl, 0, 0.02)
  
  # Add baseline drift
  baseline <- 0.05 * (wavelengths - 400) / (2499 - 400)
  
  # Combine
  spectra[i, ] <- pmax(0, pmin(1, base_spectrum + noise + baseline))
}

# Generate target variables
# Age (regression target)
age <- round(rnorm(n_samples, mean = 50, sd = 15))
age <- pmax(20, pmin(80, age))

# Class (classification target)
class_probs <- c(0.4, 0.35, 0.25)
class_labels <- c("A", "B", "C")
class <- sample(class_labels, n_samples, replace = TRUE, prob = class_probs)
class <- factor(class, levels = class_labels)

# Covariates for stratification
breed <- sample(c("Breed1", "Breed2", "Breed3"), n_samples, replace = TRUE, 
                prob = c(0.5, 0.3, 0.2))
breed <- factor(breed)

sex <- sample(c("M", "F"), n_samples, replace = TRUE, prob = c(0.6, 0.4))
sex <- factor(sex)

# Create data frame
sample_spectra <- data.frame(
  ID = sample_ids,
  Age = age,
  Class = class,
  breed = breed,
  sex = sex,
  spectra,
  stringsAsFactors = FALSE
)

# Name spectral columns with wavelengths
colnames(sample_spectra)[6:(5+n_wl)] <- as.character(wavelengths)

# Save as package data
usethis::use_data(sample_spectra, overwrite = TRUE)

cat("Sample spectral data generated and saved!\n")
cat("Dataset contains", n_samples, "samples and", n_wl, "wavelengths\n")
