## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5
)

## ----install, eval = FALSE----------------------------------------------------
# # Utilisez le chemin complet
# devtools::document("C:/Users/user/Desktop/Work/SpectroTune/spectrotune")
# devtools::install("C:/Users/user/Desktop/Work/SpectroTune/spectrotune")

## ----load---------------------------------------------------------------------
library(spectrotune)
library(ggplot2)

## ----data---------------------------------------------------------------------
data(sample_spectra)
head(sample_spectra[, 1:10])

## ----summary------------------------------------------------------------------
summary(sample_spectra$Age)
table(sample_spectra$Class)

## ----preprocess---------------------------------------------------------------
# Apply multiple pretreatments
pp <- st_preprocess(
  data = sample_spectra,
  target = "Age",
  preprocess = c("RAW", "ABS", "SG1", "SNV"),
  preprocess_params = list(SG1 = list(w = 17, p = 2, m = 1)),
  noise_range = c(700, 705)  # Exclude noisy region
)

# Check the results
names(pp$X)
dim(pp$X$RAW)

## ----model, eval = FALSE------------------------------------------------------
# # Run nested CV with multiple algorithms
# fit <- st_model(
#   X_list = pp$X,
#   y = pp$y,
#   algos = c("PLSR", "SVR", "RF"),
#   outer_k = 5,
#   outer_rep = 2,
#   inner_k = 5,
#   seed = 42,
#   verbose = TRUE
# )
# fit$summary

## ----run, eval = FALSE--------------------------------------------------------
# # Complete workflow in one call
# fit <- st_run(
#   data = sample_spectra,
#   target = "Age",
#   preprocess = c("ABS", "SNV"),
#   preprocess_params = list(SG1 = list(w = 17, p = 2, m = 1)),
#   algos = c("PLSR", "SVR","RF_PCA"),
#   outer_k = 5,
#   inner_k = 5,
#   outer_rep = 2,
#   seed = 42,
#   verbose = TRUE
# )

## ----results, eval = FALSE----------------------------------------------------
# # View performance summary
# fit$summary
# 
# # Best performing pipeline
# fit$best

## ----plot, eval = FALSE-------------------------------------------------------
# # Plot best model performance
# p <- st_plot_best(fit)
# print(p)

## ----classification, eval = FALSE---------------------------------------------
# # Classification workflow
# fit_cls <- st_run(
#   data = sample_spectra,
#   target = "Class",
#   preprocess = c("ABS", "SG1"),
#   algos = c("SVM", "RF", "GLMNET"),
#   outer_k = 5,
#   inner_k = 5,
#   outer_rep = 2,
#   seed = 42,
#   verbose = TRUE
# )
# 
# # View classification results
# fit_cls$summary
# st_plot_best(fit_cls)

## ----chain, eval = FALSE------------------------------------------------------
# # Chain preprocessing steps
# fit_chain <- st_run(
#   data = sample_spectra,
#   target = "Age",
#   preprocess = "ABS+SG1+SNV",  # Chained pipeline
#   algos = c("PLSR", "SVR"),
#   outer_k = 5,
#   inner_k = 5,
#   seed = 42
# )

## ----stratified, eval = FALSE-------------------------------------------------
# # Stratified sampling by target bins
# fit_strat <- st_run(
#   data = sample_spectra,
#   target = "Age",
#   preprocess = c("ABS", "SG1"),
#   algos = c("PLSR", "SVR"),
#   outer_k = 5,
#   inner_k = 5,
#   seed = 42,
#   dependent_sampling = "stratified_bin",
#   dependent_bins = 5
# )

## ----covariate, eval = FALSE--------------------------------------------------
# # Stratify by breed and sex
# fit_cov <- st_run(
#   data = sample_spectra,
#   target = "Age",
#   preprocess = c("ABS", "SG1"),
#   algos = c("PLSR", "SVR"),
#   outer_k = 5,
#   inner_k = 5,
#   seed = 42,
#   independent_sampling = "stratified",
#   stratify = list(breed = sample_spectra$breed,
#                   sex = sample_spectra$sex)
# )

## ----save, eval = FALSE-------------------------------------------------------
# # Fit final model on full dataset
# final_model <- st_fit_final(
#   data = sample_spectra,
#   target = "Age",
#   preprocess = "SG1",
#   algo = "SVR",
#   preprocess_params = list(w = 17, p = 2, m = 1),
#   inner_k = 5,
#   seed = 42
# )
# 
# # Save to file
# st_save_final(final_model, "my_spectral_model.rds")

