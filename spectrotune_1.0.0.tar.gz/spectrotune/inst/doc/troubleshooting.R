## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 8,
  fig.height = 5
)

## ----load---------------------------------------------------------------------
library(spectrotune)
library(ggplot2)

## ----install_devtools, eval = FALSE-------------------------------------------
# # Install required packages
# install.packages(c("devtools", "roxygen2"))
# 
# # If on Windows, install Rtools
# # Download from: https://cran.rstudio.com/bin/windows/Rtools/

## ----fix_roxygen, eval = FALSE------------------------------------------------
# # 1. Restart R/RStudio
# # 2. Remove package manually
# remove.packages("roxygen2")
# 
# # 3. Delete lock folders (Windows)
# # Navigate to: C:\Users\[username]\AppData\Local\R\win-library\[version]\
# # Delete: 00LOCK\roxygen2\ and roxygen2\ folders
# 
# # 4. Reinstall
# install.packages("roxygen2", type = "binary")

## ----fix_permissions, eval = FALSE--------------------------------------------
# # Check library paths
# .libPaths()
# 
# # Install to user library
# install.packages("package_name", lib = .libPaths()[1])
# 
# # Or run R as administrator (Windows)

## ----fix_column_names, eval = FALSE-------------------------------------------
# # Check column names
# names(your_data)
# 
# # Ensure target column exists and is properly named
# # The function will automatically detect and rename target columns
# # Make sure your target column name is consistent
# 
# # Example: If your target is "Age" but column is "age"
# names(your_data)[names(your_data) == "age"] <- "Age"

## ----fix_spectral_columns, eval = FALSE---------------------------------------
# # Check if spectral columns are numeric
# str(your_data)
# 
# # Convert to numeric if needed
# spectral_cols <- grep("^[0-9]+$", names(your_data), value = TRUE)
# your_data[spectral_cols] <- lapply(your_data[spectral_cols], as.numeric)
# 
# # Ensure column names are wavelength values
# # Example: "400", "405", "410", etc.

## ----fix_missing_values, eval = FALSE-----------------------------------------
# # Check for missing values
# sum(is.na(your_data))
# 
# # Remove rows with missing values
# your_data <- your_data[complete.cases(your_data), ]
# 
# # Or impute missing values
# # For spectra, consider interpolation
# library(zoo)
# your_data[spectral_cols] <- lapply(your_data[spectral_cols],
#                                    function(x) na.approx(x, na.rm = FALSE))

## ----fix_convergence, eval = FALSE--------------------------------------------
# # 1. Check data quality
# summary(your_data$target_variable)
# hist(your_data$target_variable)
# 
# # 2. Try different preprocessing
# pp <- st_preprocess(
#   data = your_data,
#   target = "target_variable",
#   preprocess = c("RAW", "ABS", "SNV"),  # Start simple
#   noise_range = NULL
# )
# 
# # 3. Reduce model complexity
# fit <- st_run(
#   data = your_data,
#   target = "target_variable",
#   preprocess = c("ABS"),  # Single preprocessing
#   algos = c("PLSR", "SVR"),  # Fewer algorithms
#   outer_k = 3,  # Smaller CV
#   inner_k = 3,
#   outer_rep = 1,  # Single repetition
#   seed = 42
# )

## ----fix_memory, eval = FALSE-------------------------------------------------
# # 1. Reduce dataset size
# your_data_small <- your_data[sample(nrow(your_data), 100), ]
# 
# # 2. Use fewer preprocessing methods
# preprocess_simple <- c("ABS", "SG1")
# 
# # 3. Use fewer algorithms
# algos_simple <- c("PLSR", "SVR")
# 
# # 4. Reduce CV parameters
# fit <- st_run(
#   data = your_data_small,
#   target = "target_variable",
#   preprocess = preprocess_simple,
#   algos = algos_simple,
#   outer_k = 3,
#   inner_k = 3,
#   outer_rep = 1,
#   seed = 42
# )

## ----fix_performance, eval = FALSE--------------------------------------------
# # 1. Reduce hyperparameter grids
# # Edit R/model.R to use smaller grids:
# # PLS_NCOMP_GRID <- c(5, 10, 15)  # Instead of c(5, 10, 15, 20, 25, 30)
# # SVR_C_GRID <- c(1, 10)  # Instead of c(0.1, 1, 10, 100)
# 
# # 2. Use parallel processing
# # Install and load parallel
# install.packages("parallel")
# library(parallel)
# 
# # 3. Reduce CV repetitions
# fit <- st_run(
#   data = your_data,
#   target = "target_variable",
#   preprocess = c("ABS", "SG1"),
#   algos = c("PLSR", "SVR"),
#   outer_k = 5,
#   inner_k = 5,
#   outer_rep = 1,  # Single repetition
#   seed = 42
# )

## ----fix_sg_params, eval = FALSE----------------------------------------------
# # Ensure window size is odd
# preprocess_params <- list(
#   SG1 = list(w = 17, p = 2, m = 1),  # w must be odd
#   SG2 = list(w = 21, p = 4, m = 2)   # w must be odd
# )
# 
# # Check parameter validity
# w <- 17  # Window size
# p <- 2   # Polynomial order
# m <- 1   # Derivative order
# 
# # w must be odd and > p
# if (w %% 2 == 0) stop("Window size must be odd")
# if (w <= p) stop("Window size must be greater than polynomial order")

## ----fix_wavelength_ranges, eval = FALSE--------------------------------------
# # Check available wavelengths
# wl_cols <- grep("^[0-9]+$", names(your_data), value = TRUE)
# wl_values <- as.numeric(wl_cols)
# range(wl_values)
# 
# # Use valid ranges
# pp <- st_preprocess(
#   data = your_data,
#   target = "target_variable",
#   preprocess = c("ABS", "SG1"),
#   wl_keep = c(400, 2000),  # Within available range
#   noise_range = c(700, 705)  # Within available range
# )

## ----fix_plotting, eval = FALSE-----------------------------------------------
# # 1. Check if fit object is valid
# str(fit)
# 
# # 2. Ensure plot is printed
# p <- st_plot_best(fit)
# print(p)  # Explicitly print
# 
# # 3. Check for errors in fit
# if (is.null(fit$summary)) {
#   stop("No results to plot. Check if model training completed successfully.")
# }
# 
# # 4. Try different plot options
# p <- st_plot_best(fit, return_data = TRUE)
# head(p)

## ----fix_empty_results, eval = FALSE------------------------------------------
# # 1. Check if training completed
# if (is.null(fit$summary)) {
#   cat("Model training failed. Check error messages above.\n")
# }
# 
# # 2. Verify data format
# str(your_data)
# 
# # 3. Check target variable
# summary(your_data$target_variable)
# 
# # 4. Try with minimal parameters
# fit_minimal <- st_run(
#   data = your_data,
#   target = "target_variable",
#   preprocess = "RAW",
#   algos = "PLSR",
#   outer_k = 3,
#   inner_k = 3,
#   outer_rep = 1,
#   seed = 42,
#   verbose = TRUE
# )

## ----fix_poor_performance, eval = FALSE---------------------------------------
# # 1. Check data quality
# # Look for outliers
# boxplot(your_data$target_variable)
# 
# # 2. Try different preprocessing
# preprocess_options <- c("RAW", "ABS", "SNV", "SG1", "MSC")
# for (prep in preprocess_options) {
#   fit <- st_run(
#     data = your_data,
#     target = "target_variable",
#     preprocess = prep,
#     algos = "PLSR",
#     outer_k = 5,
#     inner_k = 5,
#     seed = 42,
#     verbose = FALSE
#   )
#   cat(prep, ":", fit$best$RSQval, "\n")
# }
# 
# # 3. Check for overfitting
# # Compare calibration vs validation metrics
# fit$summary[, c("RSQcal", "RSQval")]
# 
# # 4. Try different algorithms
# algos_options <- c("PLSR", "SVR", "RF", "GLMNET")
# for (algo in algos_options) {
#   fit <- st_run(
#     data = your_data,
#     target = "target_variable",
#     preprocess = "ABS",
#     algos = algo,
#     outer_k = 5,
#     inner_k = 5,
#     seed = 42,
#     verbose = FALSE
#   )
#   cat(algo, ":", fit$best$RSQval, "\n")
# }

## ----fix_unstable_results, eval = FALSE---------------------------------------
# # 1. Increase CV repetitions
# fit <- st_run(
#   data = your_data,
#   target = "target_variable",
#   preprocess = c("ABS", "SG1"),
#   algos = c("PLSR", "SVR"),
#   outer_k = 5,
#   inner_k = 5,
#   outer_rep = 5,  # More repetitions
#   seed = 42
# )
# 
# # 2. Use stratified sampling
# fit <- st_run(
#   data = your_data,
#   target = "target_variable",
#   preprocess = c("ABS", "SG1"),
#   algos = c("PLSR", "SVR"),
#   outer_k = 5,
#   inner_k = 5,
#   outer_rep = 3,
#   dependent_sampling = "stratified_bin",
#   dependent_bins = 5,
#   seed = 42
# )
# 
# # 3. Check for data leakage
# # Ensure no target information in spectral data
# cor(your_data$target_variable, your_data[, grep("^[0-9]+$", names(your_data))])

## ----debugging, eval = FALSE--------------------------------------------------
# # Always use verbose = TRUE for debugging
# fit <- st_run(
#   data = your_data,
#   target = "target_variable",
#   preprocess = c("ABS", "SG1"),
#   algos = c("PLSR", "SVR"),
#   outer_k = 5,
#   inner_k = 5,
#   outer_rep = 2,
#   seed = 42,
#   verbose = TRUE  # Enable progress messages
# )

## ----intermediate_results, eval = FALSE---------------------------------------
# # 1. Test preprocessing separately
# pp <- st_preprocess(
#   data = your_data,
#   target = "target_variable",
#   preprocess = c("ABS", "SG1"),
#   verbose = TRUE
# )
# 
# # Check preprocessing results
# str(pp)
# dim(pp$X$ABS)
# summary(pp$y)
# 
# # 2. Test modeling separately
# fit <- st_model(
#   X_list = pp$X,
#   y = pp$y,
#   algos = "PLSR",
#   outer_k = 3,
#   inner_k = 3,
#   outer_rep = 1,
#   seed = 42,
#   verbose = TRUE
# )

## ----validate_data, eval = FALSE----------------------------------------------
# # Create data validation function
# validate_spectral_data <- function(data, target) {
#   # Check target exists
#   if (!target %in% names(data)) {
#     stop("Target column not found")
#   }
# 
#   # Check spectral columns
#   spectral_cols <- grep("^[0-9]+$", names(data), value = TRUE)
#   if (length(spectral_cols) == 0) {
#     stop("No spectral columns found")
#   }
# 
#   # Check for missing values
#   if (any(is.na(data[target]))) {
#     stop("Missing values in target variable")
#   }
# 
#   # Check for infinite values
#   if (any(is.infinite(data[target]))) {
#     stop("Infinite values in target variable")
#   }
# 
#   cat("Data validation passed!\n")
#   cat("Samples:", nrow(data), "\n")
#   cat("Wavelengths:", length(spectral_cols), "\n")
#   cat("Target range:", range(data[target]), "\n")
# }
# 
# # Use validation
# validate_spectral_data(your_data, "target_variable")

## ----error_patterns, eval = FALSE---------------------------------------------
# # Pattern 1: Column not found
# # Error: TARGET_COL %in% names(raw_df) is not TRUE
# # Solution: Check column names and target specification
# 
# # Pattern 2: Memory issues
# # Error: cannot allocate vector of size X Mb
# # Solution: Reduce dataset size or model complexity
# 
# # Pattern 3: Convergence issues
# # Warning: model did not converge
# # Solution: Check data quality and preprocessing
# 
# # Pattern 4: Package loading
# # Error in loadNamespace(x) : there is no package called 'X'
# # Solution: Install missing dependencies

